

<?php 
if ($_GET['peta']=='pasean') {
	require_once 'pasean.php';
}elseif ($_GET['peta']=='waru') {
	require_once 'waru.php';
}elseif ($_GET['peta']=='batumarmar') {
	require_once 'btmarmar.php';
}elseif ($_GET['peta']=='pegantenan') {
	require_once 'pegantenan.php';
}elseif ($_GET['peta']=='pakong') {
	require_once 'pakong.php';
}elseif ($_GET['peta']=='kadur') {
	require_once 'kadur.php';
}elseif ($_GET['peta']=='palengaan') {
	require_once 'palengaan.php';
}elseif ($_GET['peta']=='larangan') {
	require_once 'larangan.php';
}elseif ($_GET['peta']=='galis') {
	require_once 'galis.php';
}elseif ($_GET['peta']=='proppo') {
	require_once 'proppo.php';
}elseif ($_GET['peta']=='pamekasan') {
	require_once 'pamekasan.php';
}elseif ($_GET['peta']=='pademawu') {
	require_once 'pademawu.php';
}elseif ($_GET['peta']=='tlanakan') {
	require_once 'tlanakan.php';
}else{
	require_once 'lokasi.php';
 }?>
