<?php

if (isset($_POST['save'])) {
	$no = 1;
	$artikel = $_POST['artikel'];
	$save = mysqli_query ($con, "UPDATE profil SET artikel='$artikel' WHERE id='$no'");

	if($save){
		echo "<script>
		alert('Profil berhasil dirubah !');
		location=(href='index.php?profilPdmw');
		</script>";
	}else{
		echo "<script>
		alert('Profil gagal dirubah !');
		location=(href='index.php?editProfil');
		</script>";
	}
}elseif(isset($_POST['saveProf'])) {
	$no = 1;
	$namaLengkap = $_POST['namaLengkap'];
	$moto = $_POST['moto'];
	$password = md5($_POST['password']);

	if ($password == $admin['2']) {
		$setAdmin = mysqli_query($con, "UPDATE admin SET nama='$namaLengkap', ket='$moto' WHERE id_admin='$no'");
		if($setAdmin){
			echo "<script>
			alert('Profil berhasil dirubah !');
			location=(href='index.php?profil');
			</script>";
		}
	}else{
		echo "<script>
			alert('Masukkan Password Anda dengan Benar !');
			location=(href='index.php?profil=edit');
			</script>";
	}	
}elseif (isset($_POST['savePas'])) {
	$no = 1;
	$pasBaru = md5($_POST['pasBaru']);
	$lagi = md5($_POST['lagi']);

		if ($pasBaru != $lagi) {
			echo "<script>
				alert('Masukkan Password Baru dengan Benar !');
				location=(href='index.php?profil=password');
				</script>";
		}elseif ($pasBaru == $lagi) {
			$ubah = mysqli_query ($con, "UPDATE admin SET password='$pasBaru' WHERE id_admin='$no'");
			if ($ubah) {
				echo "<script>
				alert('Password berhasil dirubah !');
				location=(href='index.php?profil');
				</script>";
			}
		}
	
}

?>