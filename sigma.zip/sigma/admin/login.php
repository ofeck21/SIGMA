<?php 
session_start();
if (!empty($_SESSION['sigma'])) {
	header('location:index.php');
}
include_once 'connect.php';
?>

<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Silahkan Masuk !</title>
  <link rel="stylesheet" href="css/login.css">
</head>

<body>
  <div class="login-page">
  <h2>SILAHKAN MASUK !</h2>
  <div class="form">
    <form class="login-form" method="POST" action="">
      <input type="text" placeholder="NAMA PENGGUNA" name="username" />
      <input type="password" placeholder="KATA SANDI" name="password" />
      <button type="submit" name="login">MASUK</button>
      <p class="message">Tidak jadi ? <a href="http://localhost/sigma">Kembali ke Beranda</a></p>
    </form>
  </div>
</div>

</body>
</html>

<?php 
if (isset($_POST['login'])) {
	$u = $_POST['username'];
	$p = md5($_POST['password']);
	require_once 'admin.php';
	if ($u == $admin[1] && $p == $admin[2]) {
		$_SESSION['sigma'] = $admin[3];
		 echo "<meta http-equiv=\"refresh\" content=\"0; index.php\">";
	} else{
		echo "<script> alert('Periksa Kembali Nama Pengguna atau Kata Sandi Anda !') </script>";
	}
}
 ?>