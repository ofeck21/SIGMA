<?php 
session_start();
if (empty($_SESSION['sigma'])) {
	header('location:login.php');
}
require_once 'connect.php';
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>SIG - Maarif</title>

    <!-- Bootstrap CSS -->    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />    
    <!-- Custom styles -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />
	<link href="css/jquery-ui-1.10.4.min.css" rel="stylesheet">
  </head>

  <body>
  <!-- container section start -->
  <section id="container" class="">
     
      <header class="header dark-bg">
            <!--logo start-->
            <a href="http://localhost/sigma/admin" class="logo">SIG MAARIF <span class="lite">Admin</span></a>
            <!--logo end-->

            <div class="top-nav notification-row">                
                <!-- notificatoin dropdown start-->
                <ul class="nav pull-right top-menu">
                  
                    <!-- user login dropdown start-->
                    <li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="username"><?php echo $admin['nama']; ?></span>
                            <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu extended logout">
                            <div class="log-arrow-up"></div>
                            <li class="eborder-top">
                                <a href="?profil"><i class="icon_profile"></i>Profile</a>
                            </li>
                            <li>
                                <a href="logout.php"><i class="icon_key_alt"></i> Log Out</a>
                            </li>
                        </ul>
                    </li>
                    <!-- user login dropdown end -->
                </ul>
                <!-- notificatoin dropdown end-->
            </div>
      </header>      
      <!--header end-->
      
      <!--main content start-->
        <section class="wrapper">
          <?php 
          	if (isset($_GET['data'])) {
          		require_once 'data.php';
          	}elseif (isset($_GET['tambah'])) {
              require_once 'tambah.php';
            }elseif (isset($_GET['profil'])) {
              require_once 'profil.php';
            }elseif ($_GET['hapus']) {
              require_once 'hapus.php';
            }elseif (isset($_GET['edit'])) {
              require_once 'edit.php';
            }elseif (isset($_GET['detail'])) {
              require_once 'detail.php';
            }
            else{
          		require_once 'data.php';
          	}
          ?>

  <div class="text-right" style="position:fixed; bottom:0; right:0; margin-right:15px;">
      <div class="credits">
            Copyright &copy; 2017 - Abd Shomad
        </div>
</div>
</section>

    <!-- javascripts -->
    <script src="js/jquery.js"></script>
	<script src="js/jquery-ui-1.10.4.min.js"></script>
    <script src="js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="js/jquery-ui-1.9.2.custom.min.js"></script>
    <!-- bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- nice scroll -->
    <script src="js/jquery.scrollTo.min.js"></script>
    <script src="js/jquery.nicescroll.js" type="text/javascript"></script>

    <!--custome script for all page-->
    <script src="js/scripts.js"></script>
    
	<script src="js/jquery.slimscroll.min.js"></script>
  </body>
</html>
