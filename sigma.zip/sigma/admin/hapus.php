<?php
if (isset($_GET['hapus'])) {
	$id = $_GET['hapus'];
	$hapus = mysqli_query($con, "DELETE FROM data WHERE id_sekolah='$id'");
	if ($hapus) {
		echo "<script>
		alert('Data berhasil di hapus !');
		location=(href='?data');
		</script>";
	}else{
		echo "<script>
		alert('Data gagal di hapus !');
		location=(href='?data');
		</script>";
	}
}
?>