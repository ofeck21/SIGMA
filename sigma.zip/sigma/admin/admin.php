<?php 
include_once 'connect.php';

$q = mysqli_query($con, "SELECT * FROM admin WHERE username='$u' AND password='$p'");
$admin = mysqli_fetch_array($q);

?>