<?php 
if (isset($_POST['update'])) {
	//umum
	$statistik = $_POST['statistik']; //
	$npsn = $_POST['npsn']; //
	$nama_sekolah = $_POST['nama_sekolah']; //
	$jenjang = $_POST['jenjang']; //
	$alamat = $_POST['alamat']; //
	$kec = $_POST['kec']; //
	$pos = $_POST['pos']; //
	$email = $_POST['email']; //
	$web = $_POST['web']; //
	$latitude = $_POST['latitude']; //
	$longitude = $_POST['longitude']; //
	$kepsek = $_POST['kepsek']; //
	$tlp = $_POST['telepon']; //
	$jenis_sekolah = $_POST['jenis_sekolah']; //
	$kategori = $_POST['ketegori_sekolah']; //
	$status_ak = $_POST['status_ak']; //
	$kurikulum = $_POST['kurikulum']; //
	$jaringan = $_POST['jaringan']; //
	$status_gedung = $_POST['status_gedung']; //
	$waktu = $_POST['waktu']; //
	$th_berdiri = $_POST['th_berdiri']; //
	$luas_tanah = $_POST['luas_tanah']; //
	$luas_b = $_POST['luas_b']; //
	//siswa
	$th_pelajaran = $_POST['th_pelajaran']; //
	$siswa_l = $_POST['siswa_l']; //
	$siswa_p = $_POST['siswa_p']; //
	$jml_siswa = $_POST['jml_siswa']; //
	$jml_guru = $_POST['jml_guru']; //
	$guru_l = $_POST['guru_l']; //
	$guru_p = $_POST['guru_p']; //
	$sertifikasi = $_POST['sertifikasi']; //
	$rombong = $_POST['rombong']; //
	$skor_sekolah = $_POST['skor_sekolah']; //
	//sarana
	$meja_siswa = $_POST['meja_siswa']; //
	$kursi_siswa = $_POST['kursi_siswa']; //
	$ruang_kelas = $_POST['ruang_kelas']; //
	$ruang_guru = $_POST['ruang_guru']; //
	$ruang_tu = $_POST['ruang_tu']; //
	$listrik = $_POST['listrik']; //
	$air = $_POST['air']; // 
	$masmos = $_POST['masmos']; //
	$skor_sarpras = $_POST['skor_sarpras']; // 

	
	if ($statistik == '' || $npsn == '' || $nama_sekolah == '' || $alamat == '' || $kec == '' || $latitude == '' || $longitude == '' || $kepsek == '' || $tlp == '' || $jenis_sekolah == '' || $kategori == '' ||	$status_ak == '' || $skor_sekolah == '' ||	$skor_sarpras == '') {
		echo "<script>alert('Harap isi form dengan Lengkap');
		location=(href='index.php?edit=$idS');</script>";
	}else{
		//update data
		$q_update = mysqli_query($con, "UPDATE data SET nama_sekolah='$nama_sekolah', jenjang='$jenjang', alamat='$alamat', kec='$kec', no_statistik='$statistik', no_pokok='$npsn', jenis='$jenis_sekolah', kategori='$kategori', akreditasi='$status_ak', th_berdiri='$th_berdiri', kurikulum='$kurikulum', jar_inter='$jaringan', luas_t='$luas_tanah', luas_b='$luas_b', status_g='$status_gedung', waktu_p='$waktu', th_pelajaran='$th_pelajaran', siswa_l='$siswa_l', siswa_p='$siswa_p', jml_siswa='$jml_siswa', rombong='$rombong', guru_s='$sertifikasi', guru_l='$guru_l', guru_p='$guru_p', jumlah_guru='$jml_guru', meja_siswa='$meja_siswa', kursi_siswa='$kursi_siswa', listrik='$listrik', air='$air', masmos='$masmos', ruang_kelas='$ruang_kelas', ruang_tu='$ruang_tu', ruang_guru='$ruang_guru', pos='$pos', tlp='$tlp', email='$email', web='$web', latitude='$latitude', longitude='$longitude', kepsek='$kepsek', skor='$skor_sarpras', skor_sekolah='$skor_sekolah' WHERE id_sekolah=$idS");
		if ($q_update) {
			echo "<script>alert('Data telah diubah!');
			location=(href='index.php?data');</script>";
		}else{
			echo "<script>alert('Data GAGAL diubah!');
			location=(href='index.php?edit=$idS');</script>";
		}
	}
}

?>