<?php 
$idS = $_GET['detail'];

$editS = mysqli_query($con, "SELECT * FROM data WHERE id_sekolah=$idS");
$value = mysqli_fetch_array($editS);

?>
<div class="row">
  <div class="col-lg-12 col-md-12">
    <section class="panel panel-default">
          <header class="panel-heading">
             Keterangan Umum Sekolah
          </header>
          <div class="panel-body">
                  <div class="form-group">
                      <div class="col-sm-4">No. Statistik Sekolah </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['no_statistik'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">NPSN </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['no_pokok'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Nama Sekolah </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['nama_sekolah'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Alamat Sekolah </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['alamat'].", ".$value['kec'];?> 
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Kode Pos </div>
                      <div class="col-sm-8">
                      <?php echo ": ".$value['pos'];?>
                      </div>
                  </div>
                  <div class="form-group ">
                      <div class="col-lg-4">E-Mail </div>
                      <div class="col-lg-8">
                          <?php echo ": ".$value['email'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Wesite </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['web'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Koordinat </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['latitude'].", ".$value['longitude'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Nama Kepala Sekolah </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['kepsek'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Nomor Telepon </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['tlp'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Jenis Sekolah </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['jenis'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Kategori Sekolah </div>
                      <div class="col-sm-8">
                         <?php echo ": ".$value['kategori'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Status Akreditasi </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['akreditasi'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Kurikulum </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['kurikulum'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Memiliki Jaringan Internet </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['jar_inter'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Status Gedung </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['status_g'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Waktu Penyelenggaraan </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['waktu_p'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Tahun Berdiri </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['th_berdiri'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Luas Tanah </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['luas_t'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Luas Bangunan </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['luas_b'];?>
                      </div>
                  </div>
          </div><!-- End Panel-Body -->
      </section><!-- end panel -->
      </div>
</div>

<div class="row">
  <div class="col-lg-12 col-md-12">
    <section class="panel panel-default">
          <header class="panel-heading">
             Keadaan Siswa, Guru dan Rombong Belajar
          </header>
          <div class="panel-body">
                  <div class="form-group">
                      <div class="col-sm-4">Tahun Pelajaran </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['th_pelajaran'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Jumlah Siswa </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['jml_siswa'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Jumlah Siswa Laki-Laki</div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['siswa_l'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Jumlah Siswa Perempuan</div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['siswa_p'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Jumlah Guru </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['jumlah_guru'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Jumlah Guru Laki-Laki</div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['guru_l'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Jumlah Guru Perempuan</div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['guru_p'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Jumlah Guru Sertifikasi </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['guru_s'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Jumlah Rombong Belajar/Kelas </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['rombong'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Skor Sekolah</div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['skor_sekolah'];?>
                      </div>
                  </div>
          </div><!-- End Panel-Body -->
      </section><!-- end panel -->
      </div>
</div>

<div class="row">
  <div class="col-lg-12 col-md-12">
    <section class="panel panel-default">
          <header class="panel-heading">
             Sarana dan Prasarana
          </header>
          <div class="panel-body">
                  <div class="form-group">
                      <div class="col-sm-4">Jumlah Meja Siswa </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['meja_siswa'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Jumlah Kursi Siswa </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['kursi_siswa'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Jumlah Ruang Kelas </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['ruang_kelas'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Jumlah Ruang Guru </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['ruang_guru'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Jumlah Ruang TU </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['skor_sekolah'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Masjid/Musolla </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['masmos'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Sumber Utama Penerangan </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['listrik'];?> 
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Sumber Utama Air </div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['air'];?>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="col-sm-4">Skor Sarpras</div>
                      <div class="col-sm-8">
                          <?php echo ": ".$value['skor'];?>
                      </div>
                  </div>
          </div><!-- End Panel-Body -->
      </section><!-- end panel -->
      <?php $dt = $_GET['detail']; ?>
      <a href="?edit=<?php echo $dt;?>" class="btn btn-warning">EDIT</a>
      <a href="?data" class="btn btn-default">BATAL</a>
      </div>
</div>
