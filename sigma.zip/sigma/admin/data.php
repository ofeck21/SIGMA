 <div class="row">
           	
			<div class="col-lg-12 col-md-12">	
				<div class="panel panel-default">
					<div class="panel-heading">
						<h2><i class="icon_document_alt"></i><strong>Data Sekolah LP Maarif NU</strong></h2>
						<span style="float:right; background:#00a0df; padding: 0 5px;"><strong><a href="?tambah" style="text-decoration:none; color:white;">Tambah Data</a></strong></span>
					</div>
					<div class="panel-body">
						<table class="table bootstrap-datatable countries">
							<thead>
								<tr>
									<th>No</th>
									<th>Nama Sekolah</th>
									<th>NSS/MSM/MPSN</th>
									<th>Nama KEPSEK</th>
									<th>Alamat</th>
									<th>Tahun Berdiri</th>
									<th>Akterditasi</th>
									<th>Aksi</th>
								</tr>
							</thead>   
							<tbody>
								<?php 
								$no = 1;
								while ($row = mysqli_fetch_array($tblData)) {
									echo "<tr>
										<td>$no</td>
										<td>".$row['nama_sekolah']."</td>
										<td>".$row['no_statistik']."</td>
										<td>".$row['kepsek']."</td>
										<td>".$row['alamat']."</td>
										<td>".$row['th_berdiri']."</td>
										<td>".$row['akreditasi']."</td>
										<td><a href='?detail=$row[id_sekolah]'><span class='fa fa-'>Detail</span></a> - <a href='?edit=$row[id_sekolah]' title='edit'><span class='fa fa-edit'></span></a> - <span class='fa fa-trash'><a href='?hapus=$row[id_sekolah]' onclick='return confirm(\"Apa Anda Yakin Untuk Menghapus,,?\");'>Hapus</span> </td>
									</tr>";
									$no++;
								}
								 ?>
							</tbody>
						</table>
					</div>

				</div>	

			</div><!--/col-->
          </div>
