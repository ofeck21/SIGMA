<form class="form-horizontal " method="post" action="">
<div class="row">
	<div class="col-lg-12 col-md-12">
		<section class="panel panel-default">
          <header class="panel-heading">
             Keterangan Umum Sekolah
          </header>
          <div class="panel-body">
                  <div class="form-group">
                      <label class="col-sm-2 control-label">No. Statistik Sekolah :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="statistik" placeholder="Nama Sekolah">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">NPSN :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="npsn" placeholder="Nomor Pokok Sekolah Nasional">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Nama Sekolah :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="nama_sekolah" placeholder="Nama Sekolah">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jenjang Sekolah :</label>
                      <div class="col-sm-10">
                          <select class="form-control" name="jenjang">
                              <option> - </option>
                              <option value="SD">SD</option>
                              <option value="SMP">SMP</option>
                              <option value="MTs">MTs</option>
                              <option value="MA">MA</option>
                              <option value="SMK">SMK</option>
                           </select>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="control-label col-lg-2" for="inputSuccess">Alamat Sekolah :</label>
                      <div class="col-lg-10">
                          <div class="row">
                              <div class="col-lg-8">
                                  <input type="text" class="form-control" name="alamat" placeholder="Kelurahan/Desa">
                              </div>
                              <div class="col-lg-4">
                                  <select class="form-control" name="kec">
                                      <option>Kecamatan</option>
                                      <option value="Waru">Waru</option>
                                      <option value="Batu Marmar">Batu Marmar</option>
                                      <option value="Pamekasan">Pamekasan</option>
                                      <option value="Kadur">Kadur</option>
                                      <option value="Tlanakan">Tlanakan</option>
                                      <option value="Palengaan">Palengaan</option>
                                      <option value="Proppo">Proppo</option>
                                      <option value="Pegantenan">Pegantenan</option>
                                      <option value="Pademawu">Pademawu</option>
                                      <option value="Larangan">Larangan</option>
                                      <option value="Galis">Galis</option>
                                      <option value="Pakong">Pakong</option>
                                      <option value="Pasean">Pasean</option>
                                  </select>
                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Kode Pos :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="pos" placeholder="Kode Pos">
                      </div>
                  </div>
                  <div class="form-group ">
                      <label for="cemail" class="control-label col-lg-2">E-Mail :</label>
                      <div class="col-lg-10">
                          <input class="form-control " placeholder="example@mail.com" id="cemail" type="email" name="email" />
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Wesite :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="web" placeholder="example : www.sekolahku.sch.id">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Koordinat :</label>
                      <div class="col-sm-5">
                          <input type="text"  class="form-control" name="latitude" placeholder="Latitude, ex: -7.072424">
                      </div>
                      <div class="col-sm-5">
                          <input type="text"  class="form-control" name="longitude" placeholder="Longitude, ex: 113.499759">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Nama Kepala Sekolah :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="kepsek" placeholder="Nama Kepala Sekolah">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Nomor Telepon :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="telepon" placeholder="Nomor Telepon">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jenis Sekolah :</label>
                      <div class="col-sm-10">
                          <select class="form-control" name="jenis_sekolah">
                              <option> - </option>
                              <option value="Negeri">Negeri</option>
                              <option value="Swasta">Swasta</option>
                           </select>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Kategori Sekolah :</label>
                      <div class="col-sm-10">
                          <select class="form-control" name="ketegori_sekolah">
                              <option> - </option>
                              <option value="Dipondok">Dipondok</option>
                              <option value="Tidak Dipondok">Tidak Dipondok</option>
                           </select>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Status Akreditasi :</label>
                      <div class="col-sm-10">
                          <select class="form-control" name="status_ak">
                              <option> - </option>
                              <option value="A (Amat Baik)">A (Amat Baik)</option>
                              <option value="B (Baik)">B (Baik)</option>
                              <option value="C (Cukup)">C (Cukup)</option>
                              <option value="TT (Tidak Terakreditasi)">TT (Tidak Terakreditasi)</option>
                           </select>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Kurikulum :</label>
                      <div class="col-sm-10">
                          <select class="form-control" name="kurikulum">
                              <option> - </option>
                              <option value="KTSP">KTSP</option>
                              <option value="K-13">K-13</option>
                           </select>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Memiliki Jaringan Internet :</label>
                      <div class="col-sm-10">
                          <select class="form-control" name="jaringan">
                              <option> - </option>
                              <option value="Ya">Ya</option>
                              <option value="Tidak">Tidak</option>
                           </select>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Status Gedung :</label>
                      <div class="col-sm-10">
                          <select class="form-control" name="status_gedung">
                              <option> - </option>
                              <option value="Miliki Sendiri">Milik Sendiri</option>
                              <option value="Menumpang">Menumpang</option>
                              <option value="Sewa">Sewa</option>
                              <option value="Pinjaman">Pinjaman</option>
                           </select>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Waktu Penyelenggaraan :</label>
                      <div class="col-sm-10">
                          <select class="form-control" name="waktu">
                              <option> - </option>
                              <option value="Pagi">Pagi</option>
                              <option value="Siang">Siang</option>
                              <option value="Kombinasi">Kombinasi</option>
                           </select>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Tahun Berdiri :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="th_berdiri" placeholder="Tahun Berdiri">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Luas Tanah :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="luas_tanah" placeholder="Luas Tanah (M2)">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Luas Bangunan :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="luas_b" placeholder="Luas Gedung (M2)">
                      </div>
                  </div>
          </div><!-- End Panel-Body -->
      </section><!-- end panel -->
      </div>
</div>

<div class="row">
  <div class="col-lg-12 col-md-12">
    <section class="panel panel-default">
          <header class="panel-heading">
             Keadaan Siswa, Guru dan Rombong Belajar
          </header>
          <div class="panel-body">
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Tahun Pelajaran :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="th_pelajaran" placeholder="Tahun Pelajaran">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jumlah Siswa :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="jml_siswa" placeholder="Jumlah Siswa">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jumlah Siswa Laki-Laki:</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="siswa_l" placeholder="Jumlah Siswa">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jumlah Siswa Perempuan:</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="siswa_p" placeholder="Jumlah Siswa">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jumlah Guru :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="jml_guru" placeholder="Jumlah Guru">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jumlah Guru Laki-Laki:</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="guru_l" placeholder="Jumlah Guru">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jumlah Guru Perempuan:</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="guru_p" placeholder="Jumlah Guru">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jumlah Guru Sertifikasi :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="sertifikasi" placeholder="Jumlah Guru Sertifikasi">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jumlah Rombong Belajar/Kelas :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="rombong" placeholder="Jumlah Rombong Belajar/Kelas">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Skor Sekolah:</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="skor_sekolah" placeholder="Masukan Skor Sarana dan Prasarana">
                      </div>
                  </div>
          </div><!-- End Panel-Body -->
      </section><!-- end panel -->
      </div>
</div>

<div class="row">
  <div class="col-lg-12 col-md-12">
    <section class="panel panel-default">
          <header class="panel-heading">
             Sarana dan Prasarana
          </header>
          <div class="panel-body">
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jumlah Meja Siswa :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="meja_siswa" placeholder="Jumlah Meja Siswa Layak Pakai">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jumlah Kursi Siswa :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="kursi_siswa" placeholder="Jumlah Kursi Siswa Layak Pakai">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jumlah Ruang Kelas :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="ruang_kelas" placeholder="Jumlah Ruang Guru">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jumlah Ruang Guru :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="ruang_guru" placeholder="Jumlah Ruang Guru">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jumlah Ruang TU :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="ruang_tu" placeholder="Jumlah Ruang Tata Usaha">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Masjid/Musolla :</label>
                      <div class="col-sm-10">
                          <select class="form-control" name="masmos">
                              <option> - </option>
                              <option value="Ada">Ada</option>
                              <option value="Tidak Ada">Tidak Ada</option>
                           </select>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Sumber Utama Penerangan :</label>
                      <div class="col-sm-10">
                          <select class="form-control" name="listrik">
                              <option> - </option>
                              <option value="PLN">PLN</option>
                              <option value="Listrik Non PLN">Listrik Non PLN</option>
                              <option value="Lainnya">Lainnya</option>
                           </select>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Sumber Utama Air :</label>
                      <div class="col-sm-10">
                          <select class="form-control" name="air">
                              <option> - </option>
                              <option value="PDAM">PDAM</option>
                              <option value="Sumur Pompa">Sumur Pompa</option>
                              <option value="Sumur Timba">Sumur Timba</option>
                              <option value="Sungai">Sungai</option>
                              <option value="Air Hujan">Air Hujar</option>
                              <option value="Lainnya">Lainnya</option>
                           </select>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Skor Sarpras:</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="skor_sarpras" placeholder="Masukan Skor Sarana dan Prasarana">
                      </div>
                  </div>
          </div><!-- End Panel-Body -->
      </section><!-- end panel -->
      <input type="submit" name="simpan" class="btn btn-success" value="SIMPAN">
      <a href="?data" class="btn btn-default">BATAL</a>
      </div>
</div>
</form>

<?php require_once 'proses_tambah.php'; ?>
