<?php 
error_reporting(0);
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'sigma';

$con = mysqli_connect($host, $user, $pass, $db) or die("<span style='color:red;'>NOTE : PENGATURAN DATABASE PERLU DI SET !</span>");

$us = $_SESSION['sigma'];
$tblAdmin = mysqli_query($con, "SELECT * FROM admin WHERE nama='$us'");
$admin = mysqli_fetch_array($tblAdmin);

//select table data 
$tblData = mysqli_query($con, "SELECT * FROM data");
 ?>