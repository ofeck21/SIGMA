<?php 
$idS = $_GET['edit'];

$editS = mysqli_query($con, "SELECT * FROM data WHERE id_sekolah=$idS");
$value = mysqli_fetch_array($editS);

?>
<form class="form-horizontal " method="post" action="">
<div class="row">
	<div class="col-lg-12 col-md-12">
		<section class="panel panel-default">
          <header class="panel-heading">
             Keterangan Umum Sekolah
          </header>
          <div class="panel-body">
                  <div class="form-group">
                      <label class="col-sm-2 control-label">No. Statistik Sekolah :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="statistik" value="<?php echo $value['no_statistik'];?>">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">NPSN :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="npsn" value="<?php echo $value['no_pokok'];?>">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Nama Sekolah :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="nama_sekolah" value="<?php echo $value['nama_sekolah'];?>">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jenjang :</label>
                      <div class="col-sm-10">
                          <select class="form-control" name="jenjang">
                              <option value="<?php echo $value['jenjang'];?>"> <?php echo $value['jenjang'];?> </option>
                              <option value="SD">SD</option>
                              <option value="SMP">SMP</option>
                              <option value="MTs">MTs</option>
                              <option value="MA">MA</option>
                              <option value="SMK">SMK</option>
                           </select>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="control-label col-lg-2" for="inputSuccess">Alamat Sekolah :</label>
                      <div class="col-lg-10">
                          <div class="row">
                              <div class="col-lg-8">
                                  <input type="text" class="form-control" name="alamat" value="<?php echo $value['alamat'];?>">
                              </div>
                              <div class="col-lg-4">
                                  <select class="form-control" name="kec">
                                      <option value="<?php echo $value['kec'];?>"><?php echo $value['kec'];?></option>
                                      <option value="Waru">Waru</option>
                                      <option value="Batu Marmar">Batu Marmar</option>
                                      <option value="Pamekasan">Pamekasan</option>
                                      <option value="Kadur">Kadur</option>
                                      <option value="Tlanakan">Tlanakan</option>
                                      <option value="Palengaan">Palengaan</option>
                                      <option value="Proppo">Proppo</option>
                                      <option value="Pegantenan">Pegantenan</option>
                                      <option value="Pademawu">Pademawu</option>
                                      <option value="Larangan">Larangan</option>
                                      <option value="Galis">Galis</option>
                                      <option value="Pakong">Pakong</option>
                                      <option value="Pasean">Pasean</option>
                                  </select>
                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Kode Pos :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="pos" value="<?php echo $value['pos'];?>">
                      </div>
                  </div>
                  <div class="form-group ">
                      <label for="cemail" class="control-label col-lg-2">E-Mail :</label>
                      <div class="col-lg-10">
                          <input class="form-control " value="<?php echo $value['email'];?>" id="cemail" type="email" name="email" />
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Wesite :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="web" value="<?php echo $value['web'];?>">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Koordinat :</label>
                      <div class="col-sm-5">
                          <input type="text"  class="form-control" name="latitude" value="<?php echo $value['latitude'];?>">
                      </div>
                      <div class="col-sm-5">
                          <input type="text"  class="form-control" name="longitude" value="<?php echo $value['longitude'];?>">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Nama Kepala Sekolah :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="kepsek" value="<?php echo $value['kepsek'];?>">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Nomor Telepon :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="telepon" value="<?php echo $value['tlp'];?>">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jenis Sekolah :</label>
                      <div class="col-sm-10">
                          <select class="form-control" name="jenis_sekolah">
                              <option value="<?php echo $value['jenis'];?>"> <?php echo $value['jenis'];?> </option>
                              <option value="Negeri">Negeri</option>
                              <option value="Swasta">Swasta</option>
                           </select>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Kategori Sekolah :</label>
                      <div class="col-sm-10">
                          <select class="form-control" name="ketegori_sekolah">
                              <option value="<?php echo $value['kategori'];?>"> <?php echo $value['kategori'];?> </option>
                              <option value="Dipondok">Dipondok</option>
                              <option value="Tidak Dipondok">Tidak Dipondok</option>
                           </select>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Status Akreditasi :</label>
                      <div class="col-sm-10">
                          <select class="form-control" name="status_ak">
                              <option value="<?php echo $value['akreditasi'];?>"> <?php echo $value['akreditasi'];?> </option>
                              <option value="A (Amat Baik)">A (Amat Baik)</option>
                              <option value="B (Baik)">B (Baik)</option>
                              <option value="C (Cukup)">C (Cukup)</option>
                              <option value="TT (Tidak Terakreditasi)">TT (Tidak Terakreditasi)</option>
                           </select>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Kurikulum :</label>
                      <div class="col-sm-10">
                          <select class="form-control" name="kurikulum">
                              <option value="<?php echo $value['kurikulum'];?>"> <?php echo $value['kurikulum'];?> </option>
                              <option value="KTSP">KTSP</option>
                              <option value="K-13">K-13</option>
                           </select>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Memiliki Jaringan Internet :</label>
                      <div class="col-sm-10">
                          <select class="form-control" name="jaringan">
                              <option value="<?php echo $value['jar_inter'];?>"> <?php echo $value['jar_inter'];?> </option>
                              <option value="Ya">Ya</option>
                              <option value="Tidak">Tidak</option>
                           </select>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Status Gedung :</label>
                      <div class="col-sm-10">
                          <select class="form-control" name="status_gedung">
                              <option value="<?php echo $value['status_g'];?>"> <?php echo $value['status_g'];?> </option>
                              <option value="Miliki Sendiri">Milik Sendiri</option>
                              <option value="Menumpang">Menumpang</option>
                              <option value="Sewa">Sewa</option>
                              <option value="Pinjaman">Pinjaman</option>
                           </select>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Waktu Penyelenggaraan :</label>
                      <div class="col-sm-10">
                          <select class="form-control" name="waktu">
                              <option value="<?php echo $value['waktu_p'];?>"> <?php echo $value['waktu_p'];?> </option>
                              <option value="Pagi">Pagi</option>
                              <option value="Siang">Siang</option>
                              <option value="Kombinasi">Kombinasi</option>
                           </select>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Tahun Berdiri :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="th_berdiri" value="<?php echo $value['th_berdiri'];?>">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Luas Tanah :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="luas_tanah" value="<?php echo $value['luas_t'];?>">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Luas Bangunan :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="luas_b" value="<?php echo $value['luas_b'];?>">
                      </div>
                  </div>
          </div><!-- End Panel-Body -->
      </section><!-- end panel -->
      </div>
</div>

<div class="row">
  <div class="col-lg-12 col-md-12">
    <section class="panel panel-default">
          <header class="panel-heading">
             Keadaan Siswa, Guru dan Rombong Belajar
          </header>
          <div class="panel-body">
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Tahun Pelajaran :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="th_pelajaran" value="<?php echo $value['th_pelajaran'];?>">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jumlah Siswa :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="jml_siswa" value="<?php echo $value['jml_siswa'];?>">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jumlah Siswa Laki-Laki:</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="siswa_l" value="<?php echo $value['siswa_l'];?>">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jumlah Siswa Perempuan:</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="siswa_p" value="<?php echo $value['siswa_p'];?>">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jumlah Guru :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="jml_guru" value="<?php echo $value['jumlah_guru'];?>">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jumlah Guru Laki-Laki:</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="guru_l" value="<?php echo $value['guru_l'];?>">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jumlah Guru Perempuan:</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="guru_p" value="<?php echo $value['guru_p'];?>">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jumlah Guru Sertifikasi :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="sertifikasi" value="<?php echo $value['guru_s'];?>">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jumlah Rombong Belajar/Kelas :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="rombong" value="<?php echo $value['rombong'];?>">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Skor Sekolah:</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="skor_sekolah" value="<?php echo $value['skor_sekolah'];?>">
                      </div>
                  </div>
          </div><!-- End Panel-Body -->
      </section><!-- end panel -->
      </div>
</div>

<div class="row">
  <div class="col-lg-12 col-md-12">
    <section class="panel panel-default">
          <header class="panel-heading">
             Sarana dan Prasarana
          </header>
          <div class="panel-body">
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jumlah Meja Siswa :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="meja_siswa" value="<?php echo $value['meja_siswa'];?>">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jumlah Kursi Siswa :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="kursi_siswa" value="<?php echo $value['kursi_siswa'];?>">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jumlah Ruang Kelas :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="ruang_kelas" value="<?php echo $value['ruang_kelas'];?>">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jumlah Ruang Guru :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="ruang_guru" value="<?php echo $value['ruang_guru'];?>">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Jumlah Ruang TU :</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="ruang_tu" value="<?php echo $value['skor_sekolah'];?>">
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Masjid/Musolla :</label>
                      <div class="col-sm-10">
                          <select class="form-control" name="masmos">
                              <option value="<?php echo $value['masmos'];?>"> <?php echo $value['masmos'];?> </option>
                              <option value="Ada">Ada</option>
                              <option value="Tidak Ada">Tidak Ada</option>
                           </select>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Sumber Utama Penerangan :</label>
                      <div class="col-sm-10">
                          <select class="form-control" name="listrik">
                              <option value="<?php echo $value['listrik'];?>"> <?php echo $value['listrik'];?> </option>
                              <option value="PLN">PLN</option>
                              <option value="Listrik Non PLN">Listrik Non PLN</option>
                              <option value="Lainnya">Lainnya</option>
                           </select>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Sumber Utama Air :</label>
                      <div class="col-sm-10">
                          <select class="form-control" name="air">
                              <option value="<?php echo $value['air'];?>"> <?php echo $value['air'];?> </option>
                              <option value="PDAM">PDAM</option>
                              <option value="Sumur Pompa">Sumur Pompa</option>
                              <option value="Sumur Timba">Sumur Timba</option>
                              <option value="Sungai">Sungai</option>
                              <option value="Air Hujan">Air Hujar</option>
                              <option value="Lainnya">Lainnya</option>
                           </select>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-2 control-label">Skor Sarpras:</label>
                      <div class="col-sm-10">
                          <input type="text"  class="form-control" name="skor_sarpras" value="<?php echo $value['skor'];?>">
                      </div>
                  </div>
          </div><!-- End Panel-Body -->
      </section><!-- end panel -->
      <input type="submit" name="update" class="btn btn-success" value="SIMPAN">
      <a href="?data" class="btn btn-default">BATAL</a>
      </div>
</div>
</form>

<?php require_once 'update.php'; ?>
