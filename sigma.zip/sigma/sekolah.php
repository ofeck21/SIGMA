<div class="row">
        <div class="col-md-12">
          <div class="panel panel-success panel-dashboard">
            <div class="panel-heading centered">
            <h2 class="panel-title"><strong> Data Sekolah Dibawah Naungan LP. Maarif NU </strong></h2> 
            </div>
            <div class="panel-body">
              <table class="table table-hover table-striped table-admin">
              <thead>
                <tr>
                  	<th width="3%">No</th>
					<th width="20%">Nama Sekolah</th>
					<th width="30%">Alamat</th>
					<th width="15%">Kepala Sekolah</th>
					<th width="15%">Telepon</th>
					<th width="17%"></th>
                </tr>
              </thead>
              <tbody>
              <?php
                $data = file_get_contents('http://localhost/sigma/ambildata.php');
                $no=1;
                if(json_decode($data,true)){
                  $obj = json_decode($data);
                  foreach($obj->results as $item){
              ?>
              <tr>
                <td><?php echo $no; ?></td>
                <td><?php echo $item->nama_sekolah; ?></td>
                <td><?php echo $item->alamat; ?></td>
                <td><?php echo $item->kepsek; ?></td>
                <td><?php echo $item->tlp; ?></td>
                <td class="ctr">
                  <div class="btn-group">
                    <a href="?detail=<?php echo $item->id_sekolah; ?>" rel="tooltip" data-original-title="Lihat File" data-placement="top" class="btn btn-success">
                    <i class="fa fa-map-marker"> </i> Detail dan Lokasi</a>&nbsp;
                  </div>
                </td>
              </tr>
              <?php $no++; }}

              else{
                echo "data tidak ada.";
                } ?>
              
              </tbody>
            </table>
            </div>
            </div>
          </div>
        </div>
      </div>
    </div>


