<?php 
require_once 'admin/connect.php';

$skor = mysqli_query($con, "SELECT * FROM data ORDER BY skor DESC LIMIT 0,3") or die("Oops!");
$skors = mysqli_query($con, "SELECT * FROM data ORDER BY skor_sekolah DESC LIMIT 0,3") or die("Oops!");
?>