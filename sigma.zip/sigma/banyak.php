<?php 
require_once 'admin/connect.php';

//Select data Pasean
$pasean = mysqli_query($con, "SELECT * FROM data WHERE kec='Pasean'");
$dpasean = mysqli_fetch_array($pasean);
$jmlpasean = mysqli_num_rows($pasean);

//periksa jumlah sekolah di waru
$waru = mysqli_query($con, "SELECT * FROM data WHERE kec='Waru'");
$dwaru = mysqli_fetch_array($waru);
$jmlwaru = mysqli_num_rows($waru);

//periksa jumlah sekolah di Batu Marmar
$btmarmar = mysqli_query($con, "SELECT * FROM data WHERE kec='Batu Marmar'");
$dbtmarmar = mysqli_fetch_array($btmarmar);
$jmlbtmarmar = mysqli_num_rows($btmarmar);

//periksa jumlah sekolah di Pegantenan
$pgt = mysqli_query($con, "SELECT * FROM data WHERE kec='Pegantenan'");
$dpgt = mysqli_fetch_array($pgt);
$jmlpgt = mysqli_num_rows($pgt);

//periksa jumlah sekolah di Pakong
$pakong = mysqli_query($con, "SELECT * FROM data WHERE kec='Pakong'");
$dpakong = mysqli_fetch_array($pakong);
$jmlpakong = mysqli_num_rows($pakong);

//periksa jumlah sekolah di Kadur
$kadur = mysqli_query($con, "SELECT * FROM data WHERE kec='Kadur'");
$dkadur = mysqli_fetch_array($kadur);
$jmlkadur = mysqli_num_rows($kadur);

//periksa jumlah sekolah di Larangan
$larangan = mysqli_query($con, "SELECT * FROM data WHERE kec='Larangan'");
$dlarangan = mysqli_fetch_array($larangan);
$jmllarangan = mysqli_num_rows($larangan);

//periksa jumlah sekolah di Galis
$galis = mysqli_query($con, "SELECT * FROM data WHERE kec='Galis'");
$dgalis = mysqli_fetch_array($galis);
$jmlgalis = mysqli_num_rows($galis);

//periksa jumlah sekolah di Palengaan
$palengaan = mysqli_query($con, "SELECT * FROM data WHERE kec='Palengaan'");
$dpalengaan = mysqli_fetch_array($palengaan);
$jmlpalengaan = mysqli_num_rows($palengaan);

//periksa jumlah sekolah di Proppo
$proppo = mysqli_query($con, "SELECT * FROM data WHERE kec='Proppo'");
$dproppo = mysqli_fetch_array($proppo);
$jmlproppo = mysqli_num_rows($proppo);

//periksa jumlah sekolah di Pamekasan
$pmk = mysqli_query($con, "SELECT * FROM data WHERE kec='Pamekasan'");
$dpmk = mysqli_fetch_array($pmk);
$jmlpmk = mysqli_num_rows($pmk);

//periksa jumlah sekolah di Tlanakan
$tlanakan = mysqli_query($con, "SELECT * FROM data WHERE kec='Tlanakan'");
$dtlanakan = mysqli_fetch_array($tlanakan);
$jmltlanakan = mysqli_num_rows($tlanakan);

//periksa jumlah sekolah di Pademawu
$pademawu = mysqli_query($con, "SELECT * FROM data WHERE kec='Pademawu'");
$dpademawu = mysqli_fetch_array($pademawu);
$jmlpademawu = mysqli_num_rows($pademawu);
?>