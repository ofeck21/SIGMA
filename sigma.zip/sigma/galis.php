<?php 
$peta = $_GET['peta'];
require_once 'banyak.php';

if ($jmlgalis==0) {
?>
<div class="panel panel-success">
	<div class="panel-heading" style="text-align:center;">
		<div class="pull-left">Jumlah Sekolah : <?php echo $jmlgalis;?></div>
		<strong>Kecamantan Galis</strong>
	</div>
	<div class="panel-body">
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d63338.79321840402!2d113.51822424270856!3d-7.163568013196133!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd77d3f61bcf2cb%3A0xf0809124f4d0d0cf!2sGalis%2C+Kabupaten+Pamekasan%2C+Jawa+Timur!5e0!3m2!1sid!2sid!4v1499445665545" width="100%" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
	</div>
</div>
<?php
}else{
?>
<div class="panel panel-success">
	<div class="panel-heading" style="text-align:center;">
		<div class="pull-left">Jumlah Sekolah : <?php echo $jmlgalis;?></div>
		<strong>Kecamantan Galis</strong>
		<div class="pull-right"><a href="?peta=<?php echo $peta;?>&lihat#lihat">Lihat Data</a></div>
	</div>
	<div class="panel-body">
		<div id="map-canvas" style="width:100%;height:380px;"></div>
	</div>
</div>

<script src="https://maps.googleapis.com/maps/api/js?libraries=places&key=AIzaSyDP92zJ9grZwErMgBttVo2B-n2TuKQD8vU"></script>

<script type="text/javascript">
  function initialize() {
    
    var mapOptions = {   
        zoom: 12,
        center: new google.maps.LatLng(-7.163568,113.5182242), 
        disableDefaultUI: false
    };

    var mapElement = document.getElementById('map-canvas');

    var map = new google.maps.Map(mapElement, mapOptions);

    setMarkers(map, officeLocations);

}

var officeLocations = [
<?php
$data = file_get_contents('http://localhost/sigma/datagalis.php');
                $no=1;
                if(json_decode($data,true)){
                  $obj = json_decode($data);
                  foreach($obj->results as $item){
?>
[<?php echo $item->id_sekolah ?>,'<?php echo $item->nama_sekolah ?>','<?php echo $item->alamat ?>', <?php echo $item->longitude ?>, <?php echo $item->latitude ?>, '<?php echo $item->jenjang?>'],
<?php 
}
} 
?>    
];

function setMarkers(map, locations)
{

  var customIcons = {
            SD:{
                icon: 'pic/markerSD.png'
            },
            SMP:{
                icon: 'pic/markerSMP.png'
            },
            MTs:{
                icon: 'pic/markerMTs.png'
            },
            MA:{
                icon: 'pic/markerMA.png'
            },
            SMK:{
                icon: 'pic/markerSMK.png'
            },
            SMA:{
                icon: 'pic/markerSMA.png'
            }
        };

    for (var i = 0; i < locations.length; i++) {
       
        var office = locations[i];
        var myLatLng = new google.maps.LatLng(office[4], office[3]);
        var infowindow = new google.maps.InfoWindow({content: contentString});
         
        var contentString = 
            '<div id="content">'+
            '<div id="siteNotice">'+
            '</div>'+
            '<h5 id="firstHeading" class="firstHeading">'+ office[1] + '</h5>'+
            '<h6 id="firstHeading" class="firstHeading">'+ office[2] + '</h6>'+
            '<div id="bodyContent">'+ 
            '<a href=?detail='+office[0]+'>Info Detail</a>'+
            '</div>'+
            '</div>';

        var type = office[5];
        var icon = customIcons[type] || {};

        var marker = new google.maps.Marker({
            position: myLatLng,
            map: map,
            title: office[1],
            icon: icon.icon
        });

        google.maps.event.addListener(marker, 'click', getInfoCallback(map, contentString));
    }
}

function getInfoCallback(map, content) {
    var infowindow = new google.maps.InfoWindow({content: content});
    return function() {
            infowindow.setContent(content); 
            infowindow.open(map, this);
        };
}

initialize();
</script>
<?php
}

if (isset($_GET['lihat'])) {
?>

<div class="row">
        <div class="col-md-12">
          <div class="panel panel-success panel-dashboard">
            <div class="panel-heading centered">
              <h2 class="panel-title"><strong> Data Sekolah Dibawah Naungan LP. Maarif NU </strong></h2>
            </div>
            <div class="panel-body">
              <table class="table table-hover table-striped table-admin">
              <thead>
                <tr>
                  	<th width="3%">No</th>
					<th width="20%">Nama Sekolah</th>
					<th width="30%">Alamat</th>
					<th width="15%">Kepala Sekolah</th>
					<th width="15%">Telepon</th>
					<th width="17%"></th>
                </tr>
              </thead>
              <tbody>
              <?php
                $data = file_get_contents('http://localhost/sigma/datagalis.php');
                $no=1;
                if(json_decode($data,true)){
                  $obj = json_decode($data);
                  foreach($obj->results as $item){
              ?>
              <tr>
                <td><?php echo $no; ?></td>
                <td><?php echo $item->nama_sekolah; ?></td>
                <td><?php echo $item->alamat.", ".$item->kec; ?></td>
                <td><?php echo $item->kepsek; ?></td>
                <td><?php echo $item->tlp; ?></td>
                <td class="ctr">
                  <div class="btn-group">
                    <a href="?detail=<?php echo $item->id_sekolah; ?>" rel="tooltip" data-original-title="Lihat File" data-placement="top" class="btn btn-primary">
                    <i class="fa fa-map-marker"> </i> Detail dan Lokasi</a>&nbsp;
                  </div>
                </td>
              </tr>
              <?php $no++; }}

              else{
                echo "data tidak ada.";
                } ?>
              
              </tbody>
            </table>
            </div>
            </div>
          </div>
        </div>
      </div>
    </div>

<?php
}
?>
