<!DOCTYPE html>
<html>
<head>
	<title>SIG Maarif - Pamekasan</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<script type="text/javascript" src="js/jquery.js"></script>
	<link rel="icon" type="img/icon" href="pic/logo.png">
</head>
<body>

<div class="container">
	<div class="judul">
	<img src="pic/logo.png" width="120" style="float:left; margin-right:5px;">
		<h3>Sistem Informasi Geografis (SIG)</h3>
		<h2>Pemetaan Sekolah Dibawah Naungan LP. Maarif NU</h2>
		<h3>Kabupaten Pamekasan</h3>
	</div>

    <nav class="navbar navbar-inverse" role="navigation">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Status</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-ex1-collapse pull-right">
          <ul class="nav navbar-nav">
            <li><a href="index.php"><i class="fa fa-home"></i> HALAMAN DEPAN</a></li>
            <li><a href="?data"><i class="fa fa-list-ul"></i> DATA SEKOLAH </a></li>
            <li><a href="?peta"><i class="fa fa-map-marker"></i> LOKASI SEKOLAH</a></li>
            <li><a href="#about" data-toggle="modal" data-target="#about"><i class="fa fa-user"></i> TENTANG</a></li>
          </ul>
        </div><!-- /.navbar-collapse -->
      </nav>

	<div class="content">
<?php 
if (isset($_GET['data'])) {
	include_once 'sekolah.php';
}elseif (isset($_GET['detail'])) {
  require_once 'detail.php';
}
else{
 ?>

	<?php
		if (isset($_GET['peta'])) {
			require_once 'peta.php';
		}else{
			require_once 'beranda.php';
		}
}
?>
	</div>

	<div class="footer">
		<small>Copyright &copy; 2017 | Abd Shomad - 2013.02.02.0.0004</small>
	</div>
</div>

<!-- Modal -->
<div class="modal fade" id="about" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title" id="myModalLabel">TENTANG</h4>
      </div>
      <div class="modal-body">
        <h4>SISTEM INFORMASI GEOGRAFIS PEMETAAN SEKOLAH DIBAWAH NAUNGAN LP. MAARIF NU KABUPATEN PAMEKASAN BERBASIS WEBGIS</h4>
        <p>Program ini dibuat dengan menggunakan Google Maps API. Menginformasikan tentang lokasi sekolah dibawah naungan LP. Maarif NU Kabupaten Pamekasan</p>
        <p>
        	Oleh : Abd Shomad
        </p>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script src="js/bootstrap-hover-dropdown.js"></script>
<script src="js/script.js"></script>
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/datatable-bootstrap.js"></script>
<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});
</script>
</body>
</html>

