<?php require_once 'banyak.php'; ?>
<div class="peta">
	
	<div id="maps">
		<a href="?peta=pasean"><img src="pic/pasean.png" data-toggle="tooltip" data-placement="top" title="Pasean = <?php echo $jmlpasean; ?> Sekolah" class="pic pasean"></a>
		<a href="?peta=waru"><img src="pic/waru.png" data-toggle="tooltip" data-placement="right" title="Waru = <?php echo $jmlwaru; ?> Sekolah" class="pic waru"></a>
		<a href="?peta=batumarmar"><img src="pic/batumarmar.png" data-toggle="tooltip" data-placement="top" title="Batu Marmar = <?php echo $jmlbtmarmar; ?> Sekolah" class="pic batumarmar"></a>
		<a href="?peta=pegantenan"><img src="pic/pegantenan.png" data-toggle="tooltip" data-placement="top" title="Pegantenan = <?php echo $jmlpgt; ?> Sekolah" class="pic pegantenan"></a>
		<a href="?peta=pakong"><img src="pic/pakong.png" data-toggle="tooltip" data-placement="right" title="Pakong = <?php echo $jmlpakong; ?> Sekolah" class="pic pakong"></a>
		<a href="?peta=palengaan"><img src="pic/palengaan.png" data-toggle="tooltip" data-placement="left" title="Palengaan = <?php echo $jmlpalengaan; ?> Sekolah"  class="pic palengaan"></a>
		<a href="?peta=kadur"><img src="pic/kadur.png" data-toggle="tooltip" data-placement="right" title="Kadur = <?php echo $jmlkadur; ?> Sekolah"  class="pic kadur"></a>
		<a href="?peta=proppo"><img src="pic/proppo.png" data-toggle="tooltip" data-placement="left" title="Proppo = <?php echo $jmlproppo; ?> Sekolah"  class="pic proppo"></a>
		<a href="?peta=larangan"><img src="pic/larangan.png" data-toggle="tooltip" data-placement="top" title="Larangan = <?php echo $jmllarangan; ?> Sekolah" class="pic larangan"></a>
		<a href="?peta=galis"><img src="pic/galis.png" data-toggle="tooltip" data-placement="right" title="Galis = <?php echo $jmlgalis; ?> Sekolah" class="pic galis"></a>
		<a href="?peta=tlanakan"><img src="pic/tlanakan.png" data-toggle="tooltip" data-placement="bottom" title="Tlanakan = <?php echo $jmltlanakan; ?> Sekolah" class="pic tlanakan"></a>
		<a href="?peta=pamekasan"><img src="pic/pamekasan.png" data-toggle="tooltip" data-placement="top" title="Pamekasan = <?php echo $jmlpmk; ?> Sekolah" class="pic pamekasan"></a>
		<a href="?peta=pademawu"><img src="pic/pademawu.png" data-toggle="tooltip" data-placement="bottom" title="Pademawu = <?php echo $jmlpademawu; ?> Sekolah" class="pic pademawu"></a>
	</div>
	<div class="info">
		<div class="panel panel-default">
			<div class="panel-heading">
				<strong>Keterangan</strong> 
			</div>
			<div class="panel-body">
				<div style="background:#483737; padding:3px; font-weight:bold; color:#fff;">Pasean</div>
				<div style="background:#808000; padding:3px; font-weight:bold; color:#fff;">Batu Marmar</div>
				<div style="background:#c87137; padding:3px; font-weight:bold; color:#fff;">Waru</div>
				<div style="background:#800080; padding:3px; font-weight:bold; color:#fff;">Pegantenan</div>
				<div style="background:#ff00ff; padding:3px; font-weight:bold; color:#fff;">Pakong</div>
				<div style="background:#ff6600; padding:3px; font-weight:bold; color:#fff;">Palengaan</div>
				<div style="background:#00ff00; padding:3px; font-weight:bold; color:#fff;">Kadur</div>
				<div style="background:#ff8080; padding:3px; font-weight:bold; color:#fff;">Larangan</div>
				<div style="background:#502d16; padding:3px; font-weight:bold; color:#fff;">Proppo</div>
				<div style="background:#008080; padding:3px; font-weight:bold; color:#fff;">Pamekasan</div>
				<div style="background:#ffff00; padding:3px; font-weight:bold; color:#fff;">Tlanakan</div>
				<div style="background:#504416; padding:3px; font-weight:bold; color:#fff;">Pademawu</div>
				<div style="background:#008000; padding:3px; font-weight:bold; color:#fff;">Galis</div>
			</div>
		</div>
	</div>
	<div class="prestasi pull-right">
		<div class="panel panel-default">
			<div class="panel-heading">
				<strong>Daftar Sekolah Terbaik</strong>
			</div>
			<div class="panel-body">
				<div class="panel panel-success">
					<div class="panel-heading">
						<strong>Sarana dan Prasarana</strong>
					</div>
					<div class="panel-body">
						<?php 
						require_once 'prestasi.php';
							$no = 1;
							while ($row = mysqli_fetch_array($skor)) {
								echo $no.". ".$row['nama_sekolah']."<br>";
								$no++;
							}
						 ?>
					</div>
				</div>
				<div class="panel panel-warning">
					<div class="panel-heading">
						<strong>Keadaan Guru dan Siswa</strong>
					</div>
					<div class="panel-body">
						<?php
						$n=1; 
						while ($row = mysqli_fetch_array($skors)) {
							echo $n.". ".$row['nama_sekolah']."<br>";
							$n++;
						}
						 ?>
					</div>
				</div>
				
				<hr>
				<small>NB: Berdasarkan Data Survey Lapangan Tahun 2017</small>
			</div>
		</div>
	</div>
	<div class="cp">&copy; Peta Pamekasan</div>
</div>
