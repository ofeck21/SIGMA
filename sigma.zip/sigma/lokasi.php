<div class="row">

        <div class="col-md-12">
          <div class="panel panel-success">
            <div class="panel-heading">
              <h2 class="panel-title"><strong> PETA LOKASI SEKOLAH DIBAWAH NAUNGAN LP. MAARIF NU KABUPATEN PAMEKASAN </strong></h2>
            </div>
            <div class="panel-body">
              <div id="map" style="width:100%;height:380px;"></div>

<script src="https://maps.googleapis.com/maps/api/js?libraries=places&key=AIzaSyDP92zJ9grZwErMgBttVo2B-n2TuKQD8vU"></script>

<script type="text/javascript">
  function initialize() {
    
    var mapOptions = {   
        zoom: 10,
        center: new google.maps.LatLng(-7.072424, 113.499759), 
        disableDefaultUI: false
    };

    var mapElement = document.getElementById('map');

    var map = new google.maps.Map(mapElement, mapOptions);

    setMarkers(map, officeLocations);

}

var officeLocations = [
<?php
$data = file_get_contents('http://localhost/sigma/ambildata.php');
                $no=1;
                if(json_decode($data,true)){
                  $obj = json_decode($data);
                  foreach($obj->results as $item){
?>
[<?php echo $item->id_sekolah ?>,'<?php echo $item->nama_sekolah ?>','<?php echo $item->alamat ?>', <?php echo $item->longitude ?>, <?php echo $item->latitude ?>,'<?php echo $item->jenjang ?>'],
<?php 
}
} 
?>    
];

function setMarkers(map, locations)
{
    var customIcons = {
            SD:{
                icon: 'pic/markerSD.png'
            },
            SMP:{
                icon: 'pic/markerSMP.png'
            },
            MTs:{
                icon: 'pic/markerMTs.png'
            },
            MA:{
                icon: 'pic/markerMA.png'
            },
            SMK:{
                icon: 'pic/markerSMK.png'
            },
            SMA:{
                icon: 'pic/markerSMA.png'
            }
        };

    for (var i = 0; i < locations.length; i++) {
       
        var office = locations[i];
        var myLatLng = new google.maps.LatLng(office[4], office[3]);
        var infowindow = new google.maps.InfoWindow({content: contentString});
         
        var contentString = 
            '<div id="content">'+
            '<div id="siteNotice">'+
            '</div>'+
            '<h5 id="firstHeading" class="firstHeading">'+ office[1] + '</h5>'+
            '<h6 id="firstHeading" class="firstHeading">'+ office[2] + '</h6>'+
            '<div id="bodyContent">'+ 
            '<a href=?detail='+office[0]+'>Info Detail</a>'+
            '</div>'+
            '</div>';
        
        var type = office[5];
        var icon = customIcons[type] || {};

        var marker = new google.maps.Marker({
            position: myLatLng,
            map: map,
            title: office[1],
            icon: icon.icon
        });

        google.maps.event.addListener(marker, 'click', getInfoCallback(map, contentString));
    }
}

function getInfoCallback(map, content) {
    var infowindow = new google.maps.InfoWindow({content: content});
    return function() {
            infowindow.setContent(content); 
            infowindow.open(map, this);
        };
}

initialize();
</script>
            </div>
          </div>
        </div>
        </div>
      </div>
    </div>