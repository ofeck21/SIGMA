<?php 
require_once 'koneksi.php';
$Q = mysql_query("SELECT * FROM data WHERE kec='Waru'")or die(mysql_error());
if($Q){
 $posts = array();
      if(mysql_num_rows($Q))
      {
             while($post = mysql_fetch_assoc($Q)){
                     $posts[] = $post;
             }
      }  
      $data = json_encode(array('results'=>$posts));
      echo $data;                     
}
 ?>